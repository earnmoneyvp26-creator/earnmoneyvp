
export default function Landing(){
return <div className="page">
<h1>CCTV Simulator Pro</h1>
<p>Modern camera monitoring dashboard demo.</p>
<a href="/dashboard">Open Dashboard</a>
</div>
}
