
import CameraCard from '../components/CameraCard';

export default function Dashboard(){
return <div className="page">
<h1>Dashboard</h1>
<div className="grid">
{[1,2,3,4,5,6].map(x=><CameraCard key={x} id={x}/>)}
</div>
</div>
}
