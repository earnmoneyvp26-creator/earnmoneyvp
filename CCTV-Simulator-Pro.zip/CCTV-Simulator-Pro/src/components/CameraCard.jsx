
export default function CameraCard({id}){
return <div className="card">
<img src={`https://picsum.photos/400/250?random=${id}`}/>
<h3>Camera #{id}</h3>
<p>Demo Location</p>
<span>● ONLINE</span>
</div>
}
