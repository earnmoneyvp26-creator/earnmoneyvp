
import React from 'react';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Signup from './pages/Signup';

export default function App(){
 return <BrowserRouter>
  <Routes>
   <Route path="/" element={<Landing/>}/>
   <Route path="/login" element={<Login/>}/>
   <Route path="/signup" element={<Signup/>}/>
   <Route path="/dashboard" element={<Dashboard/>}/>
  </Routes>
 </BrowserRouter>
}
